﻿namespace GSBADF.Datas
{


    partial class DataSetGSBADF
    {
        partial class DataTable1DataTable
        {
        }
    }
}

namespace GSBADF.Datas.DataSetGSBADFTableAdapters {
    
    
    public partial class tbAjoutTableAdapter {
    }
}
