﻿using GSBADF.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBADF.Forms
{
    public partial class FormAjout : Form
    {
        public FormAjout()
        {
            InitializeComponent();
        }

        private void BtnValid_Click(object sender, EventArgs e)
        {
            Datas.DataSetGSBADFTableAdapters.tbAjoutTableAdapter tbAjoutTableAdapter = new Datas.DataSetGSBADFTableAdapters.tbAjoutTableAdapter();
            tbAjoutTableAdapter.Connection = new System.Data.SqlClient.SqlConnection(Classes.Security.ConnectionString);
            int res = tbAjoutTableAdapter.Insert(this.txtTitre.Text, this.txtCom.Text, double.Parse(this.txtHT.Text), double.Parse(this.txtTTC.Text), double.Parse(this.txtTVA.Text), this.txtPaiementType.Text, Security.Encrypt(this.txtPaiementCom.Text));
            if (res == 0)
            {
                MessageBox.Show("Echec de l'insertion.", "GSBADF", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                this.Close();
            }
        }
    }
}
