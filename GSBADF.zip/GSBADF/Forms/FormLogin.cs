﻿using GSBADF.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBADF.Forms
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private bool isValid() 
        {
            if (txtLogin.Text.TrimStart() == String.Empty)
            {
                MessageBox.Show("User name is required! Length >=5", "Error");
                return false;
            }else if (txtPassword.Text.TrimStart() == String.Empty)
            {
                MessageBox.Show("Password is required! Length >=8", "Error");
                return false;
            }
            return true;
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                using (SqlConnection conn = new SqlConnection(Security.ConnectionString))
                {
                    string query = "SELECT * FROM tbUtilisateur WHERE login = '" + txtLogin.Text.Trim() +
                        "'AND password = '" + txtPassword.Text.Trim() + "'";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dta = new DataTable();
                    sda.Fill(dta);
                    if (dta.Rows.Count == 1)
                    {
                        Classes.Tools.CurrentUser = new Models.User()
                        {
                            Login = txtLogin.Text.Trim(),
                            Password= txtPassword.Text.Trim(),
                        };
                        this.DialogResult = DialogResult.OK;
                    }
                }
            }
        }
    }
}
