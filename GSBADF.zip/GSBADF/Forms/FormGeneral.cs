﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSBADF.Forms
{
    public partial class FormGeneral : Form
    {
        public FormGeneral()
        {
            InitializeComponent();
        }

        private void FormGeneral_Load(object sender, EventArgs e)
        {
            this.toolStripUser.Text = $"{Classes.Tools.CurrentUser.Login}";
        }

        private void TsmiQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //-----------------------------------------------//
        //----    Note de frais                      ----//
        private void TsmiListe_Click(object sender, EventArgs e)
        {
            Forms.FormList frm = new FormList();
            frm.MdiParent = this;
            frm.Show();
        }

        private void TsmiAjouter_Click(object sender, EventArgs e)
        {
            Forms.FormAjout frm = new FormAjout();
            frm.MdiParent = this;
            frm.Show();
        }
        //-----------------------------------------------//

        public void SetMessage(string text) { this.toolStripMessage.Text = text; }
    }
}
