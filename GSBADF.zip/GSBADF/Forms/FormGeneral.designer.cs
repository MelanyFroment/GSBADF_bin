﻿
namespace GSBADF.Forms
{
    partial class FormGeneral
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuStripGeneral = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiQuit = new System.Windows.Forms.ToolStripMenuItem();
            this.stStripGeneral = new System.Windows.Forms.StatusStrip();
            this.toolStripSociety = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.mnuNDF = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiListe = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAjouter = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuStripGeneral.SuspendLayout();
            this.stStripGeneral.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuStripGeneral
            // 
            this.mnuStripGeneral.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuNDF});
            this.mnuStripGeneral.Location = new System.Drawing.Point(0, 0);
            this.mnuStripGeneral.Name = "mnuStripGeneral";
            this.mnuStripGeneral.Size = new System.Drawing.Size(800, 24);
            this.mnuStripGeneral.TabIndex = 0;
            this.mnuStripGeneral.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiQuit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(54, 20);
            this.mnuFile.Text = "&Fichier";
            // 
            // tsmiQuit
            // 
            this.tsmiQuit.Name = "tsmiQuit";
            this.tsmiQuit.Size = new System.Drawing.Size(180, 22);
            this.tsmiQuit.Text = "&Quitter";
            this.tsmiQuit.Click += new System.EventHandler(this.TsmiQuit_Click);
            // 
            // stStripGeneral
            // 
            this.stStripGeneral.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSociety,
            this.toolStripMessage,
            this.toolStripSeparator,
            this.toolStripUser});
            this.stStripGeneral.Location = new System.Drawing.Point(0, 426);
            this.stStripGeneral.Name = "stStripGeneral";
            this.stStripGeneral.Size = new System.Drawing.Size(800, 24);
            this.stStripGeneral.TabIndex = 2;
            this.stStripGeneral.Text = "statusStrip1";
            // 
            // toolStripSociety
            // 
            this.toolStripSociety.Name = "toolStripSociety";
            this.toolStripSociety.Size = new System.Drawing.Size(42, 19);
            this.toolStripSociety.Text = "GSB ©";
            // 
            // toolStripMessage
            // 
            this.toolStripMessage.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.toolStripMessage.Name = "toolStripMessage";
            this.toolStripMessage.Size = new System.Drawing.Size(14, 19);
            this.toolStripMessage.Text = " ";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(725, 19);
            this.toolStripSeparator.Spring = true;
            // 
            // toolStripUser
            // 
            this.toolStripUser.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.toolStripUser.Name = "toolStripUser";
            this.toolStripUser.Size = new System.Drawing.Size(4, 19);
            // 
            // mnuNDF
            // 
            this.mnuNDF.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiListe,
            this.tsmiAjouter});
            this.mnuNDF.Name = "mnuNDF";
            this.mnuNDF.Size = new System.Drawing.Size(86, 20);
            this.mnuNDF.Text = "&Note de frais";
            // 
            // tsmiListe
            // 
            this.tsmiListe.Name = "tsmiListe";
            this.tsmiListe.Size = new System.Drawing.Size(180, 22);
            this.tsmiListe.Text = "&Liste";
            this.tsmiListe.Click += new System.EventHandler(this.TsmiListe_Click);
            // 
            // tsmiAjouter
            // 
            this.tsmiAjouter.Name = "tsmiAjouter";
            this.tsmiAjouter.Size = new System.Drawing.Size(180, 22);
            this.tsmiAjouter.Text = "&Ajouter";
            this.tsmiAjouter.Click += new System.EventHandler(this.TsmiAjouter_Click);
            // 
            // FormGeneral
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.stStripGeneral);
            this.Controls.Add(this.mnuStripGeneral);
            this.IsMdiContainer = true;
            this.Name = "FormGeneral";
            this.Text = "Gestion des comptes rendus";
            this.Load += new System.EventHandler(this.FormGeneral_Load);
            this.mnuStripGeneral.ResumeLayout(false);
            this.mnuStripGeneral.PerformLayout();
            this.stStripGeneral.ResumeLayout(false);
            this.stStripGeneral.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuStripGeneral;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem tsmiQuit;
        private System.Windows.Forms.StatusStrip stStripGeneral;
        private System.Windows.Forms.ToolStripStatusLabel toolStripSociety;
        private System.Windows.Forms.ToolStripStatusLabel toolStripMessage;
        private System.Windows.Forms.ToolStripStatusLabel toolStripSeparator;
        private System.Windows.Forms.ToolStripStatusLabel toolStripUser;
        private System.Windows.Forms.ToolStripMenuItem mnuNDF;
        private System.Windows.Forms.ToolStripMenuItem tsmiListe;
        private System.Windows.Forms.ToolStripMenuItem tsmiAjouter;
    }
}