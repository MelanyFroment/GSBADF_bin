﻿namespace GSBADF.Forms
{
    partial class FormList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormList));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnRefresh = new System.Windows.Forms.ToolStripButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgvListColNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColCom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColHT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColTVA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColTTC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvListColCarte = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Paiement_Commentaire = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnRefresh});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1111, 27);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnRefresh
            // 
            this.btnRefresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btnRefresh.Image")));
            this.btnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(76, 24);
            this.btnRefresh.Text = "Rafraichir";
            this.btnRefresh.Click += new System.EventHandler(this.BtnRefresh_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgvListColNum,
            this.dgvListColTitle,
            this.dgvListColCom,
            this.dgvListColHT,
            this.dgvListColTVA,
            this.dgvListColTTC,
            this.dgvListColCarte,
            this.Paiement_Commentaire});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1111, 483);
            this.dataGridView1.TabIndex = 0;
            // 
            // dgvListColNum
            // 
            this.dgvListColNum.DataPropertyName = "Numero";
            this.dgvListColNum.HeaderText = "N°";
            this.dgvListColNum.MinimumWidth = 6;
            this.dgvListColNum.Name = "dgvListColNum";
            this.dgvListColNum.ReadOnly = true;
            this.dgvListColNum.Width = 125;
            // 
            // dgvListColTitle
            // 
            this.dgvListColTitle.DataPropertyName = "Titre";
            this.dgvListColTitle.HeaderText = "Titre";
            this.dgvListColTitle.MinimumWidth = 6;
            this.dgvListColTitle.Name = "dgvListColTitle";
            this.dgvListColTitle.ReadOnly = true;
            this.dgvListColTitle.Width = 125;
            // 
            // dgvListColCom
            // 
            this.dgvListColCom.DataPropertyName = "Commentaire";
            this.dgvListColCom.HeaderText = "Commentaire";
            this.dgvListColCom.MinimumWidth = 6;
            this.dgvListColCom.Name = "dgvListColCom";
            this.dgvListColCom.ReadOnly = true;
            this.dgvListColCom.Width = 125;
            // 
            // dgvListColHT
            // 
            this.dgvListColHT.DataPropertyName = "Montant_HT";
            dataGridViewCellStyle1.Format = "C2";
            dataGridViewCellStyle1.NullValue = null;
            this.dgvListColHT.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvListColHT.HeaderText = "Montant HT";
            this.dgvListColHT.MinimumWidth = 6;
            this.dgvListColHT.Name = "dgvListColHT";
            this.dgvListColHT.ReadOnly = true;
            this.dgvListColHT.Width = 125;
            // 
            // dgvListColTVA
            // 
            this.dgvListColTVA.DataPropertyName = "Montant_TVA";
            dataGridViewCellStyle2.Format = "C2";
            dataGridViewCellStyle2.NullValue = null;
            this.dgvListColTVA.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvListColTVA.HeaderText = "Montant TVA";
            this.dgvListColTVA.MinimumWidth = 6;
            this.dgvListColTVA.Name = "dgvListColTVA";
            this.dgvListColTVA.ReadOnly = true;
            this.dgvListColTVA.Width = 125;
            // 
            // dgvListColTTC
            // 
            this.dgvListColTTC.DataPropertyName = "Montant_TTC";
            dataGridViewCellStyle3.Format = "C2";
            dataGridViewCellStyle3.NullValue = null;
            this.dgvListColTTC.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvListColTTC.HeaderText = "Montant TTC";
            this.dgvListColTTC.MinimumWidth = 6;
            this.dgvListColTTC.Name = "dgvListColTTC";
            this.dgvListColTTC.ReadOnly = true;
            this.dgvListColTTC.Width = 125;
            // 
            // dgvListColCarte
            // 
            this.dgvListColCarte.DataPropertyName = "Paiement_Type";
            dataGridViewCellStyle4.NullValue = null;
            this.dgvListColCarte.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvListColCarte.HeaderText = "Paiement Type";
            this.dgvListColCarte.MinimumWidth = 6;
            this.dgvListColCarte.Name = "dgvListColCarte";
            this.dgvListColCarte.ReadOnly = true;
            this.dgvListColCarte.Width = 125;
            // 
            // Paiement_Commentaire
            // 
            this.Paiement_Commentaire.DataPropertyName = "Paiement_Commentaire";
            this.Paiement_Commentaire.HeaderText = "Paiement Commentaire";
            this.Paiement_Commentaire.MinimumWidth = 6;
            this.Paiement_Commentaire.Name = "Paiement_Commentaire";
            this.Paiement_Commentaire.ReadOnly = true;
            this.Paiement_Commentaire.Width = 125;
            // 
            // FormList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1111, 510);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "FormList";
            this.Text = "FormList";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btnRefresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColCom;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColHT;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColTVA;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColTTC;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgvListColCarte;
        private System.Windows.Forms.DataGridViewTextBoxColumn Paiement_Commentaire;
    }
}